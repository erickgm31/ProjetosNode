// Verifica se existe um usuário conectado
const usuarioLogado = localStorage.getItem("usuarioLogado");

if (!usuarioLogado) {
    window.location.href = "../Login/login.html";
} else {
    const usuario = JSON.parse(usuarioLogado);

    // Exibe o nome do usuário
    const nomeUsuario = document.getElementById("nome-usuario");
    const avatarUsuario = document.getElementById("usuario-avatar");

    nomeUsuario.textContent = usuario.nome;
    avatarUsuario.textContent = usuario.nome.charAt(0).toUpperCase();
}

// Botão de sair
const botaoSair = document.getElementById("btn-sair");

botaoSair.addEventListener("click", () => {
    localStorage.removeItem("usuarioLogado");

    window.location.href = "../Login/login.html";
});