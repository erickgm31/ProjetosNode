const formLogin = document.getElementById("form-login");
const campoUsuario = document.getElementById("usuario");
const campoSenha = document.getElementById("senha");
const mensagemErro = document.getElementById("erro-login");

formLogin.addEventListener("submit", async (event) => {
    event.preventDefault();

    const usuarioDigitado = campoUsuario.value.trim();
    const senhaDigitada = campoSenha.value;

    mensagemErro.textContent = "";

    try {
        const resposta = await fetch("./usuarios.json");

        if (!resposta.ok) {
            throw new Error("Não foi possível carregar os usuários.");
        }

        const dados = await resposta.json();

        const usuarioEncontrado = dados.usuarios.find((usuario) => {
            return (
                usuario.usuario.toLowerCase() === usuarioDigitado.toLowerCase() &&
                usuario.senha === senhaDigitada
            );
        });

        if (!usuarioEncontrado) {
            mensagemErro.textContent = "Usuário ou senha incorretos.";
            return;
        }

        // Salva os dados da sessão
        const sessao = {
            id: usuarioEncontrado.id,
            usuario: usuarioEncontrado.usuario,
            nome: usuarioEncontrado.nome
        };

        localStorage.setItem("usuarioLogado", JSON.stringify(sessao));

        // Acessa o catálogo
        window.location.href = "../Catalogo/catalogo.html";

    } catch (erro) {
        console.error(erro);
        mensagemErro.textContent = "Erro ao realizar login. Verifique o servidor.";
    }
});